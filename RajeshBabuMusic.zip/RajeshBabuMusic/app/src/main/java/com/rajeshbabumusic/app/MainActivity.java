package com.rajeshbabumusic.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int PICK_AUDIO = 1001;
    private Uri selectedAudio;
    private MediaPlayer player;
    private TextView selectedLabel;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFF111111);

        TextView title = new TextView(this);
        title.setText("RAJESH BABU MUSIC");
        title.setTextColor(0xFFFFD27A);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 24, 0, 12);
        root.addView(title, match());

        TextView subtitle = new TextView(this);
        subtitle.setText("మీ పాటలు • మీ మ్యూజిక్ • మీ రింగ్‌టోన్");
        subtitle.setTextColor(0xFFFFFFFF);
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, 32);
        root.addView(subtitle, match());

        Button choose = button("1. MP3 పాటను ఎంచుకోండి");
        choose.setOnClickListener(v -> chooseAudio());
        root.addView(choose, matchWithMargins());

        selectedLabel = new TextView(this);
        selectedLabel.setText("ఇంకా పాట ఎంచుకోలేదు");
        selectedLabel.setTextColor(0xFFDDDDDD);
        selectedLabel.setTextSize(14);
        selectedLabel.setGravity(Gravity.CENTER);
        selectedLabel.setPadding(0, 18, 0, 18);
        root.addView(selectedLabel, match());

        Button play = button("2. పాట వినండి / ఆపండి");
        play.setOnClickListener(v -> togglePlayback());
        root.addView(play, matchWithMargins());

        Button ringtone = button("3. నా ఫోన్ Ringtoneగా పెట్టండి");
        ringtone.setOnClickListener(v -> setAsRingtone());
        root.addView(ringtone, matchWithMargins());

        Button jio = button("4. JioTunes ఎంపికలను చూడండి");
        jio.setOnClickListener(v -> openJioTunes());
        root.addView(jio, matchWithMargins());

        TextView note = new TextView(this);
        note.setText("గమనిక: ఈ యాప్ మీ ఫోన్ రింగ్‌టోన్‌ను మార్చగలదు. Jio Caller Tuneను నేరుగా మార్చడానికి Jio అనుమతి / అధికారిక సేవ అవసరం.");
        note.setTextColor(0xFFBBBBBB);
        note.setTextSize(13);
        note.setPadding(0, 28, 0, 0);
        root.addView(note, match());
        setContentView(root);
    }

    private LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(-1, -2);
    }
    private LinearLayout.LayoutParams matchWithMargins() {
        LinearLayout.LayoutParams p = match(); p.setMargins(0, 9, 0, 9); return p;
    }
    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setTextSize(15); return b;
    }

    private void chooseAudio() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        startActivityForResult(i, PICK_AUDIO);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_AUDIO && resultCode == RESULT_OK && data != null) {
            selectedAudio = data.getData();
            if (selectedAudio != null) {
                getContentResolver().takePersistableUriPermission(selectedAudio, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                String name = selectedAudio.getLastPathSegment();
                selectedLabel.setText("ఎంచుకున్న పాట: " + (name == null ? "Audio file" : name));
                Toast.makeText(this, "పాట ఎంపికైంది", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void togglePlayback() {
        if (selectedAudio == null) { toast("ముందుగా MP3 పాటను ఎంచుకోండి"); return; }
        try {
            if (player != null && player.isPlaying()) { player.pause(); return; }
            if (player != null) { player.release(); player = null; }
            player = new MediaPlayer();
            player.setDataSource(this, selectedAudio);
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnCompletionListener(mp -> { mp.release(); player = null; });
            player.prepareAsync();
        } catch (Exception e) { toast("ఈ ఆడియోను ప్లే చేయలేకపోయాం"); }
    }

    private void setAsRingtone() {
        if (selectedAudio == null) { toast("ముందుగా MP3 పాటను ఎంచుకోండి"); return; }
        if (!Settings.System.canWrite(this)) {
            Intent permission = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(permission);
            toast("Ringtone మార్చడానికి అనుమతి ఇవ్వండి. తర్వాత మళ్లీ బటన్ నొక్కండి.");
            return;
        }
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, "RajeshBabu_Custom_Ringtone.mp3");
            values.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mpeg");
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Ringtones");
                values.put(MediaStore.Audio.Media.IS_RINGTONE, true);
                values.put(MediaStore.Audio.Media.IS_NOTIFICATION, false);
                values.put(MediaStore.Audio.Media.IS_ALARM, false);
            }
            Uri destination = getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);
            if (destination == null) throw new Exception("Could not create ringtone file");
            try (InputStream in = getContentResolver().openInputStream(selectedAudio);
                 OutputStream out = getContentResolver().openOutputStream(destination)) {
                if (in == null || out == null) throw new Exception("Could not read or write audio");
                byte[] buffer = new byte[8192]; int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            }
            RingtoneManager.setActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE, destination);
            toast("మీ ఫోన్ Ringtone విజయవంతంగా మార్చబడింది!");
        } catch (Exception e) {
            toast("Ringtone మార్చలేకపోయాం. మరో MP3తో ప్రయత్నించండి.");
        }
    }

    private void openJioTunes() {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.jio.com/jcms/apps/jiotunes/"));
        try { startActivity(i); } catch (Exception e) { toast("JioTunes పేజీని తెరవలేకపోయాం"); }
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    @Override protected void onDestroy() {
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }
}
