RAJESH BABU MUSIC — Android Studio Project

ఈ ప్రాజెక్ట్‌లో ఉన్నవి:
1) ఫోన్‌లోని MP3 / ఆడియో ఫైల్‌ను ఎంచుకోవడం
2) పాటను వినడం / Pause చేయడం
3) Android ఫోన్‌కు Default Ringtoneగా పెట్టడం
4) JioTunes అధికారిక పేజీని తెరవడం

ముఖ్యమైన పరిమితి:
ఈ యాప్ Jio నెట్‌వర్క్ Caller Tuneను నేరుగా మార్చదు. Jio Caller Tune కోసం Jio అధికారిక కేటలాగ్, సేవా నిబంధనలు మరియు అవసరమైన అనుమతులు వర్తిస్తాయి.

APK తయారీ:
- కంప్యూటర్‌లో Android Studio ఇన్‌స్టాల్ చేయండి.
- ఈ ఫోల్డర్‌ను Android Studioలో Open చేయండి.
- Gradle Sync పూర్తయ్యాక Build > Build Bundle(s) / APK(s) > Build APK(s) ఎంచుకోండి.
- APK సాధారణంగా app/build/outputs/apk/debug/app-debug.apk వద్ద వస్తుంది.
- ఆ APKను మీరే నమ్మే వ్యక్తులతో మాత్రమే పంచుకోండి. ఇతరుల ఫోన్లలో install చేయడానికి వారి అనుమతి అవసరం.

గమనిక: ఈ ప్రాజెక్ట్ source code మాత్రమే; ఈ వాతావరణంలో Android SDK / Gradle build tools లేనందున APK compile చేయలేదు. Android Studioలో build చేసి పరీక్షించాలి.


GitHub ద్వారా APK తయారు చేయాలంటే (కంప్యూటర్ అవసరం లేకుండా):
1) ZIP ఫైల్‌ను Extract చేయండి.
2) GitHubలో కొత్త Repository సృష్టించండి.
3) ఈ ప్రాజెక్ట్‌లోని ఫైళ్లన్నీ Repositoryకి Upload చేయండి ( .github ఫోల్డర్ సహా).
4) GitHubలో Actions ట్యాబ్ తెరవండి.
5) “Build Android APK” workflow ఎంచుకుని “Run workflow” నొక్కండి.
6) Build పూర్తయ్యాక Artifactsలో RajeshBabuMusic-debug-apk ZIPను Download చేయండి.
7) దానిలోని app-debug.apkను మీ Android ఫోన్‌కు పంపి Install చేయండి.

గమనిక: APK install చేయడానికి ఫోన్‌లో అవసరమైతే “Install unknown apps” అనుమతి ఇవ్వాలి. APKను నమ్మకమైన వారికే పంపండి.
